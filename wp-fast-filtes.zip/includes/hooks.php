<?php
add_shortcode('wp-fast-filtes','dms_get_posts');
add_action( 'wp_enqueue_scripts','dms_enqueue_scripts');